===========================================================
      DRIVETRAIN SIMULATOR - SHEAR FORCE 
===========================================================
Developed by: Kaden Dadabhoy

This tool calculates the acceleration, speed, and traction limits 
of a dual-wheel-size drivetrain setup. It accounts for motor curves, 
gearbox reductions, and pulley ratios to ensure both wheel sizes 
are synced correctly.

-----------------------------------------------------------
HOW TO USE:
-----------------------------------------------------------
1. EDIT THE INPUT FILE:
   - Open 'DrivetrainInputeTemplate.txt' in Notepad.
   - Update the numbers (Weight, Kv, Gear Ratio, etc.) to match 
     your robot's specs.
   - Save the file.

2. RUN THE SIMULATOR:
   - Double-click the simulator .exe file.
   - When prompted for a filename, press [ENTER] to use the 
     default 'DrivetrainInputeTemplate.txt'.
   - The program will display the loaded data for verification.

3. EXPORT RESULTS (Optional):
   - The program will ask for a name for your CSV results.
   - Type a name like 'run1' and press [ENTER].
   - This will create a 'run1.csv' file in this folder which 
     you can open in Excel to view graphs and detailed data.

4. RE-RUN:
   - You can edit the .txt file and type 'y' in the program 
     to run the simulation again without closing the window.

-----------------------------------------------------------
TROUBLESHOOTING:
-----------------------------------------------------------
* "Could not find file": Ensure the .txt file and the .exe 
  are in the same folder.
* "Pulley ratios do not match": This means your front and 
  rear wheel speeds are not synced. Check your pulley tooth 
  counts vs. your wheel diameters!
* CSV won't open: If you have the CSV file open in Excel, the 
  program cannot overwrite it. Close Excel and try again.

===========================================================